def move_robot():
    print("Robot moving...")

if __name__ == "__main__":
    move_robot()
